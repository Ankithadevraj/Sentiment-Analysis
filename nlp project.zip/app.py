# Import Required Libraries
import numpy as np
import pandas as pd
import re
import pickle
from transformers import pipeline

# Load Pre-trained Transformer Sentiment Model
sentiment_pipeline = pipeline(
    "sentiment-analysis",
    model="cardiffnlp/twitter-roberta-base-sentiment",
    framework="pt"
)

# Function to clean text (HTML tags and special characters)
def clean_text(text):
    # Remove HTML tags
    text = re.sub(r'<.*?>', '', text)
    # Remove special characters and digits
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    # Convert to lowercase
    return text.lower()

# Inference Example
review = """Terrible. Complete trash. Brainless tripe. Insulting to anyone who isn't 
an 8 year old fan boy..."""

# Preprocess the text
cleaned_review = clean_text(review)

# Predict Sentiment using RoBERTa Model
results = sentiment_pipeline(cleaned_review)

# Mapping model label to human-readable format
sentiment_map = {0: "Negative", 1: "Neutral", 2: "Positive"}
label_id = int(results[0]['label'].split('_')[-1])
sentiment_label = sentiment_map[label_id]
score = results[0]['score']

# Output
print("Input Review:", review)
print("Cleaned Text:", cleaned_review)
print("Predicted Sentiment:", sentiment_label)
print("Confidence Score:", round(score, 2))